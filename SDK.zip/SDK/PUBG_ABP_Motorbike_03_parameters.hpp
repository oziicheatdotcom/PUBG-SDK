#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ABP_Motorbike_03.ABP_Motorbike_03_C.TickBikePose
struct UABP_Motorbike_03_C_TickBikePose_Params
{
};

// Function ABP_Motorbike_03.ABP_Motorbike_03_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Motorbike_03_AnimGraphNode_ModifyBone_79E6A0D24EED59EEE71332B0CBAFEDBB
struct UABP_Motorbike_03_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Motorbike_03_AnimGraphNode_ModifyBone_79E6A0D24EED59EEE71332B0CBAFEDBB_Params
{
};

// Function ABP_Motorbike_03.ABP_Motorbike_03_C.BlueprintUpdateAnimation
struct UABP_Motorbike_03_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function ABP_Motorbike_03.ABP_Motorbike_03_C.ExecuteUbergraph_ABP_Motorbike_03
struct UABP_Motorbike_03_C_ExecuteUbergraph_ABP_Motorbike_03_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
