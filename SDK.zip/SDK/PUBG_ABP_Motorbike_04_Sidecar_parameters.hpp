#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ABP_Motorbike_04_Sidecar.ABP_Motorbike_04_Sidecar_C.TickBikePose
struct UABP_Motorbike_04_Sidecar_C_TickBikePose_Params
{
};

// Function ABP_Motorbike_04_Sidecar.ABP_Motorbike_04_Sidecar_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Motorbike_04_Sidecar_AnimGraphNode_ModifyBone_667EFEB64E62473E948009AB4A214191
struct UABP_Motorbike_04_Sidecar_C_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Motorbike_04_Sidecar_AnimGraphNode_ModifyBone_667EFEB64E62473E948009AB4A214191_Params
{
};

// Function ABP_Motorbike_04_Sidecar.ABP_Motorbike_04_Sidecar_C.BlueprintUpdateAnimation
struct UABP_Motorbike_04_Sidecar_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function ABP_Motorbike_04_Sidecar.ABP_Motorbike_04_Sidecar_C.ExecuteUbergraph_ABP_Motorbike_04_Sidecar
struct UABP_Motorbike_04_Sidecar_C_ExecuteUbergraph_ABP_Motorbike_04_Sidecar_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
