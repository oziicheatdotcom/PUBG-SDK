#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BloodSpotWidget.BloodSpotWidget_C.Construct
struct UBloodSpotWidget_C_Construct_Params
{
};

// Function BloodSpotWidget.BloodSpotWidget_C.Finish
struct UBloodSpotWidget_C_Finish_Params
{
};

// Function BloodSpotWidget.BloodSpotWidget_C.ExecuteUbergraph_BloodSpotWidget
struct UBloodSpotWidget_C_ExecuteUbergraph_BloodSpotWidget_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
