#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace Classes
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct ComboBoxOption.ComboBoxOption
// 0x0028
struct FComboBoxOption
{
	struct FString                                     Option_2_C6581DBE410A7C103FF128A81BE47388;                // 0x0000(0x0010) (CPF_Edit, CPF_BlueprintVisible, CPF_ZeroConstructor)
	struct FText                                       DisplayOptionName_5_71F6878D4F686E950AAE279207CBAB84;     // 0x0010(0x0018) (CPF_Edit, CPF_BlueprintVisible)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
