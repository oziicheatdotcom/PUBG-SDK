// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.HIddenEnd__DelegateSignature
// (FUNC_Public, FUNC_Delegate, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void UBP_WeaponSlotWidget_C::HIddenEnd__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.HIddenEnd__DelegateSignature");

	UBP_WeaponSlotWidget_C_HIddenEnd__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.HIddenStart__DelegateSignature
// (FUNC_Public, FUNC_Delegate, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void UBP_WeaponSlotWidget_C::HIddenStart__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.HIddenStart__DelegateSignature");

	UBP_WeaponSlotWidget_C_HIddenStart__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.ShowEnd__DelegateSignature
// (FUNC_Public, FUNC_Delegate, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void UBP_WeaponSlotWidget_C::ShowEnd__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.ShowEnd__DelegateSignature");

	UBP_WeaponSlotWidget_C_ShowEnd__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.ShowStart__DelegateSignature
// (FUNC_Public, FUNC_Delegate, FUNC_BlueprintCallable, FUNC_BlueprintEvent)

void UBP_WeaponSlotWidget_C::ShowStart__DelegateSignature()
{
	static auto fn = UObject::FindObject<UFunction>("Function BP_WeaponSlotWidget.BP_WeaponSlotWidget_C.ShowStart__DelegateSignature");

	UBP_WeaponSlotWidget_C_ShowStart__DelegateSignature_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
