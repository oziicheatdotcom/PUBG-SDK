#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_FppWeaponListSlotWidget.BP_FppWeaponListSlotWidget_C.HIddenEnd__DelegateSignature
struct UBP_FppWeaponListSlotWidget_C_HIddenEnd__DelegateSignature_Params
{
};

// Function BP_FppWeaponListSlotWidget.BP_FppWeaponListSlotWidget_C.HIddenStart__DelegateSignature
struct UBP_FppWeaponListSlotWidget_C_HIddenStart__DelegateSignature_Params
{
};

// Function BP_FppWeaponListSlotWidget.BP_FppWeaponListSlotWidget_C.ShowEnd__DelegateSignature
struct UBP_FppWeaponListSlotWidget_C_ShowEnd__DelegateSignature_Params
{
};

// Function BP_FppWeaponListSlotWidget.BP_FppWeaponListSlotWidget_C.ShowStart__DelegateSignature
struct UBP_FppWeaponListSlotWidget_C_ShowStart__DelegateSignature_Params
{
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
