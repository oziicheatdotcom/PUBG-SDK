#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Dacia_Animation.Dacia_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Dacia_Animation_AnimGraphNode_ModifyBone_719092E14E4BB5CA865A9189AABCA18D
struct UDacia_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Dacia_Animation_AnimGraphNode_ModifyBone_719092E14E4BB5CA865A9189AABCA18D_Params
{
};

// Function Dacia_Animation.Dacia_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Dacia_Animation_AnimGraphNode_ModifyBone_8AADA72D4702CF0AC25A53A719905896
struct UDacia_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Dacia_Animation_AnimGraphNode_ModifyBone_8AADA72D4702CF0AC25A53A719905896_Params
{
};

// Function Dacia_Animation.Dacia_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Dacia_Animation_AnimGraphNode_ModifyBone_8B502CF54ED760CF23396D8775CD4D7E
struct UDacia_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Dacia_Animation_AnimGraphNode_ModifyBone_8B502CF54ED760CF23396D8775CD4D7E_Params
{
};

// Function Dacia_Animation.Dacia_Animation_C.BlueprintUpdateAnimation
struct UDacia_Animation_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function Dacia_Animation.Dacia_Animation_C.ExecuteUbergraph_Dacia_Animation
struct UDacia_Animation_C_ExecuteUbergraph_Dacia_Animation_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
