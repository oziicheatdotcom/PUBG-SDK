#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_91EBDE704D07CF5113244082F024DC0D
struct UBuggy_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_91EBDE704D07CF5113244082F024DC0D_Params
{
};

// Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_E34AF524415141E20929AFA9D1ABA4DB
struct UBuggy_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_E34AF524415141E20929AFA9D1ABA4DB_Params
{
};

// Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_EDBD6D4749B887DE53739C9812504058
struct UBuggy_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_EDBD6D4749B887DE53739C9812504058_Params
{
};

// Function Buggy_Animation.Buggy_Animation_C.BlueprintUpdateAnimation
struct UBuggy_Animation_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function Buggy_Animation.Buggy_Animation_C.ExecuteUbergraph_Buggy_Animation
struct UBuggy_Animation_C_ExecuteUbergraph_Buggy_Animation_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
