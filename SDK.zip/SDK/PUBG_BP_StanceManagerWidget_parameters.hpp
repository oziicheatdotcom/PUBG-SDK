#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function BP_StanceManagerWidget.BP_StanceManagerWidget_C.OnDriver
struct UBP_StanceManagerWidget_C_OnDriver_Params
{
};

// Function BP_StanceManagerWidget.BP_StanceManagerWidget_C.OnRider
struct UBP_StanceManagerWidget_C_OnRider_Params
{
};

// Function BP_StanceManagerWidget.BP_StanceManagerWidget_C.ExecuteUbergraph_BP_StanceManagerWidget
struct UBP_StanceManagerWidget_C_ExecuteUbergraph_BP_StanceManagerWidget_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
