#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Boat_PG117_Animation.Boat_PG117_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Boat_PG117_Animation_AnimGraphNode_ModifyBone_64A4DFC849F2AC37DED7E693D6450034
struct UBoat_PG117_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Boat_PG117_Animation_AnimGraphNode_ModifyBone_64A4DFC849F2AC37DED7E693D6450034_Params
{
};

// Function Boat_PG117_Animation.Boat_PG117_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Boat_PG117_Animation_AnimGraphNode_ModifyBone_23B5532142004C9B1C5E36A8005A6FD9
struct UBoat_PG117_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Boat_PG117_Animation_AnimGraphNode_ModifyBone_23B5532142004C9B1C5E36A8005A6FD9_Params
{
};

// Function Boat_PG117_Animation.Boat_PG117_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Boat_PG117_Animation_AnimGraphNode_ModifyBone_8057CE8141CBA4DBCBB2FC8BC84934CE
struct UBoat_PG117_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Boat_PG117_Animation_AnimGraphNode_ModifyBone_8057CE8141CBA4DBCBB2FC8BC84934CE_Params
{
};

// Function Boat_PG117_Animation.Boat_PG117_Animation_C.BlueprintUpdateAnimation
struct UBoat_PG117_Animation_C_BlueprintUpdateAnimation_Params
{
	float*                                             DeltaTimeX;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

// Function Boat_PG117_Animation.Boat_PG117_Animation_C.ExecuteUbergraph_Boat_PG117_Animation
struct UBoat_PG117_Animation_C_ExecuteUbergraph_Boat_PG117_Animation_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
