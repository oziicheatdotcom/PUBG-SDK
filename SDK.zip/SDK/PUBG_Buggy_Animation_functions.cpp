// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_91EBDE704D07CF5113244082F024DC0D
// (FUNC_BlueprintEvent)

void UBuggy_Animation_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_91EBDE704D07CF5113244082F024DC0D()
{
	static auto fn = UObject::FindObject<UFunction>("Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_91EBDE704D07CF5113244082F024DC0D");

	UBuggy_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_91EBDE704D07CF5113244082F024DC0D_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_E34AF524415141E20929AFA9D1ABA4DB
// (FUNC_BlueprintEvent)

void UBuggy_Animation_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_E34AF524415141E20929AFA9D1ABA4DB()
{
	static auto fn = UObject::FindObject<UFunction>("Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_E34AF524415141E20929AFA9D1ABA4DB");

	UBuggy_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_E34AF524415141E20929AFA9D1ABA4DB_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_EDBD6D4749B887DE53739C9812504058
// (FUNC_BlueprintEvent)

void UBuggy_Animation_C::EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_EDBD6D4749B887DE53739C9812504058()
{
	static auto fn = UObject::FindObject<UFunction>("Function Buggy_Animation.Buggy_Animation_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_EDBD6D4749B887DE53739C9812504058");

	UBuggy_Animation_C_EvaluateGraphExposedInputs_ExecuteUbergraph_Buggy_Animation_AnimGraphNode_ModifyBone_EDBD6D4749B887DE53739C9812504058_Params params;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Buggy_Animation.Buggy_Animation_C.BlueprintUpdateAnimation
// (FUNC_Event, FUNC_Public, FUNC_BlueprintEvent)
// Parameters:
// float*                         DeltaTimeX                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void UBuggy_Animation_C::BlueprintUpdateAnimation(float* DeltaTimeX)
{
	static auto fn = UObject::FindObject<UFunction>("Function Buggy_Animation.Buggy_Animation_C.BlueprintUpdateAnimation");

	UBuggy_Animation_C_BlueprintUpdateAnimation_Params params;
	params.DeltaTimeX = DeltaTimeX;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


// Function Buggy_Animation.Buggy_Animation_C.ExecuteUbergraph_Buggy_Animation
// ()
// Parameters:
// int                            EntryPoint                     (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)

void UBuggy_Animation_C::ExecuteUbergraph_Buggy_Animation(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function Buggy_Animation.Buggy_Animation_C.ExecuteUbergraph_Buggy_Animation");

	UBuggy_Animation_C_ExecuteUbergraph_Buggy_Animation_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
