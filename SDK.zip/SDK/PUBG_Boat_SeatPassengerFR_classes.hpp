#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

namespace Classes
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass Boat_SeatPassengerFR.Boat_SeatPassengerFR_C
// 0x0000 (0x0454 - 0x0454)
class ABoat_SeatPassengerFR_C : public AVehicleSeatPassenger_C
{
public:

	static UClass* StaticClass()
	{
		static auto ptr = UObject::FindClass("BlueprintGeneratedClass Boat_SeatPassengerFR.Boat_SeatPassengerFR_C");
		return ptr;
	}

};


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
