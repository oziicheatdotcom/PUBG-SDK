#pragma once

// PlayerUnknown's Battlegrounds (2.4.24) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace Classes
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function CharacterProxyBase.CharacterProxyBase_C.UserConstructionScript
struct ACharacterProxyBase_C_UserConstructionScript_Params
{
};

// Function CharacterProxyBase.CharacterProxyBase_C.ReceiveBeginPlay
struct ACharacterProxyBase_C_ReceiveBeginPlay_Params
{
};

// Function CharacterProxyBase.CharacterProxyBase_C.ExecuteUbergraph_CharacterProxyBase
struct ACharacterProxyBase_C_ExecuteUbergraph_CharacterProxyBase_Params
{
	int                                                EntryPoint;                                               // (CPF_Parm, CPF_ZeroConstructor, CPF_IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
